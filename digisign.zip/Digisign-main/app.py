from flask import Flask, render_template, request, redirect,Response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import LargeBinary
import sqlite3
import qrcode
import PIL
import mimetypes



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///files.db'
db = SQLAlchemy(app)

@app.route("/", methods=["GET"])
def index():
    return render_template("create.html")
    

if __name__ == "__main__":
    with app.app_context():
        db.create_all() #creates image
    app.run(debug=True) 




