# Pius Gumo
# 14/08/2023
# This is the controller for creating, reading, updating and deleting posts

from flask import Blueprint, render_template, abort, request
from models.Post import Post
from models.Group import Group
from models.User import User
from datetime import datetime
import os
import qrcode

controller = Blueprint("posts", __name__, template_folder="templates")


@controller.route("/", methods=["GET"])
def index():
    posts = Post.all()
    return render_template("posts/index.html", posts=posts)


@controller.route("/new", methods=["POST"])
def create():
    # check for the required fields
    required_fields = ["title", "start_date", "end_date", "post_type"]

    for field in required_fields:
        if field not in request.form:
            return abort(400, f"Required field {field} is missing")

    # available post types image,html,link
    if request.form["post_type"] == "image":
        print("Hello")
        # store the image in the static/images folder
        image = request.files["image"]
        image.save(f"static/images/{image.filename}")

        # create the post
        post = Post(
            title=request.form["title"],
            type="IMAGE",
            startDate=request.form["start_date"],
            endDate=request.form["end_date"],
            imageLink=f"static/images/{image.filename}",
            state="DRAFT",
        )

        

        # save the post
        post.insert()
        

    elif request.form["post_type"] == "html":
        # create the post
        post = Post(
            title=request.form["title"],
            type="HTML",
            startDate=request.form["start_date"],
            endDate=request.form["end_date"],
            htmlContent=request.form["htmlContent"],
            state="DRAFT",
        )
        # save the post
        post.insert()

    elif request.form["post_type"] == "link":
        # create the post
        post = Post(
            title=request.form["title"],
            type="WEB_LINK",
            startDate=request.form["start_date"],
            endDate=request.form["end_date"],
            webLink=request.form["web_link"],
            state="DRAFT",
        )
        link = post.web_link
        qr = qrcode.QRCode(version = 1,
                           error_correction = qrcode.constants.ERROR_CORRECT_L,
                           box_size = 30,
                           border = 2)
        qr.add_data(link)
        qr.make(fit=True)

        filenames = []
        filenames = getFiles()
        amount = len(filenames)
        name = str(amount)  +".jpg"

        while name in filenames:
            amount = amount +1         
            name = name = str(amount)  +".jpg"
        
        img = qr.make_image()
        img.save("static/images/"+name)
        post.insert()
        
    # save the post groups
    if "post_groups" in request.form:
        post.save_groups(request.form["post_groups"])

    # redirect to the post create page with a success message
    return render_template("posts/create.html", success="Post created successfully",groups=Group.all())


@controller.route("/new", methods=["GET"])
def new():
    groups = Group.all()
    # return the form in templates/posts/create.html
    return render_template("posts/create.html", groups=groups)


    
@controller.route("/display")
def display():
    filenames = []
    filenames = getFiles()
    return  render_template("posts/display.html", filenames = filenames)

def getFiles():
    filenames = []
    directory_path = "static/images"
    for filename in os.listdir(directory_path):
        if filename.endswith('.jpg') or filename.endswith('.png'):  # Add more file extensions if needed
            filenames.append(filename)
    return filenames
